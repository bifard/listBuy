import {renderMainWindow} from './renderMainWindow.js';
renderMainWindow();


