import {renderMainWindow} from './renderMainWindow.js'
export function renderVerRegWindow() {
    let verRegWindow = `<div class="window">
    <div class="verification_conteiner">
        <div class="nav">
            <img class="nav_img" src="img/previous.svg" alt="">
            <nav class="nav_nav">Главная</nav>
        </div>
        <div class="windowForm">
        </div>
    </div>
    </div>`;
    let rend = document.querySelector('.rend');
    rend.innerHTML = verRegWindow;

    let buttonReturn = document.querySelector('.nav_img');
    buttonReturn.addEventListener('click', () => {
        renderMainWindow()
    })
}